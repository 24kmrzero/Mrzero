# Supabase Setup

## 1. Project
1. supabase.com → New project (save the DB password)
2. Settings → API → copy **Project URL** and **anon public key**
3. Paste both into the top of `script.js`

## 2. Tables

```sql
create table courses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  level text,
  price numeric default 0,
  description text,
  lessons_count int default 0,
  status text default 'published',
  created_at timestamptz default now()
);

create table students (
  id uuid primary key default gen_random_uuid(),
  auth_id uuid unique,
  name text not null,
  email text unique not null,
  whatsapp text,
  country text,
  experience text,
  status text default 'active',
  created_at timestamptz default now()
);

create table enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  course_id uuid references courses(id) on delete cascade,
  progress int default 0,
  last_lesson text,
  enrolled_at timestamptz default now(),
  unique (student_id, course_id)
);

create table payments (
  id uuid primary key default gen_random_uuid(),
  invoice_no text unique,
  student_id uuid references students(id) on delete cascade,
  course_id uuid references courses(id),
  amount numeric not null,
  method text,
  status text default 'pending',
  paid_at timestamptz,
  created_at timestamptz default now()
);

create table certificates (
  id uuid primary key default gen_random_uuid(),
  student_id uuid references students(id) on delete cascade,
  course_id uuid references courses(id),
  certificate_no text unique,
  issued_at timestamptz default now(),
  file_url text
);

create table live_sessions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  starts_at timestamptz not null,
  join_url text,
  recording_url text,
  status text default 'scheduled'
);

create table testimonials (
  id uuid primary key default gen_random_uuid(),
  student_name text not null,
  city text,
  rating int check (rating between 1 and 5),
  message text not null,
  is_published boolean default false,
  created_at timestamptz default now()
);

create table enquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  whatsapp text,
  service text,
  message text,
  created_at timestamptz default now()
);

create table site_settings (
  key text primary key,
  value text
);
```

## 3. Auth
Authentication → Providers → enable **Email**.
Create the two demo users manually for testing.

## 4. Row Level Security

```sql
alter table courses enable row level security;
create policy "public read courses" on courses
  for select using (status = 'published');

alter table testimonials enable row level security;
create policy "public read testimonials" on testimonials
  for select using (is_published = true);

alter table enquiries enable row level security;
create policy "anyone can submit" on enquiries
  for insert with check (true);

alter table enrollments enable row level security;
create policy "own enrollments" on enrollments
  for select using (
    student_id in (select id from students where auth_id = auth.uid())
  );

alter table payments enable row level security;
create policy "own payments" on payments
  for select using (
    student_id in (select id from students where auth_id = auth.uid())
  );
```

## 5. Wire it up
Uncomment the Supabase block at the bottom of `script.js` and replace the hardcoded rows in the dashboards with the returned data.
