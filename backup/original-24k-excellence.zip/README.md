# 24K Excellence Education System

Static site + student panel + admin panel. Built with plain HTML/CSS/JS — no build step, no dependencies.

## Files

| File | Purpose |
|---|---|
| `index.html` | Home (hero, mentor, services, courses, reviews, contact, footer) |
| `courses.html` | Choose Your Course page (Free + Premium) |
| `login.html` | Student / Admin login (dummy) |
| `student-dashboard.html` | My Courses, Charts, Certificate, Profile Setting, Payment History, Need Help, Logout |
| `admin-dashboard.html` | Dashboard, Courses, Students, Live Sessions, Testimonials, Payments, Enquiries, Settings |
| `styles.css` | All styling and animations |
| `script.js` | Nav, reveal animations, panel switching, charts, Supabase hooks |
| `assets/logo.png` | Brand logo |
| `assets/mentor.png` | Mentor photo |

## Deploy to GitHub Pages

1. Create a repo, e.g. `24k-excellence`
2. Upload **all files, keeping the `assets/` folder** (drag the whole folder in)
3. Settings → Pages → Source: `main` / `(root)` → Save
4. Live at `https://<username>.github.io/24k-excellence`

## Demo logins

| Role | Email | Password |
|---|---|---|
| Student | student@24kexcellence.com | 123456 |
| Admin | admin@24kexcellence.com | admin123 |

Login is front-end only — any password works. Replace with Supabase Auth when ready (see `SUPABASE_SETUP.md`).

## Editing content

- Mentor name / bio / stats → `index.html`, or later from Admin → Settings once Supabase is wired
- Prices → `index.html` and `courses.html` (search for `$149`)
- Contact numbers → search `+92 300 1234567`
- Colours → `styles.css`, `:root` block at the top

## Replacing images

Drop new files into `assets/` with the same names (`logo.png`, `mentor.png`) — nothing else needs to change.
For the hero photo, a transparent-background PNG cut-out looks best.
